Details of TAO_Assignment_02.dtd file and TAO_Assignment_02.xml file:

Domain : Event Moderation System
Root Node EMS has 06 main Elements. These elements define all concepts from our Tbox created in Assignment 01.
The 06 elements are as follows:
1.	Person
2.	Event
3.	Club
4,	OrganizingTeam
5.	Sports
6.	Co-CurricularActivities.
Elements 1-4 cover section 3.1 of Assignment-01, and elements 5 and 6 cover sections 3.2 and 3.3 respectively.

Each element is further described in comments made in our .dtd file.

TAO_Assignment_02.xml file is populated with dummy data appropriately, with a reasonable number of examples per element.

We have used various Queries as necessary in our Individual Assignments, executed on this .xml file.
